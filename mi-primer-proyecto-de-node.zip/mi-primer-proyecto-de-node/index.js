//Este es el mensaje de bienvenida
console.log("esta es la puerta de entrada del proyecto")


//esta es la parte intermedia


//checkeos necesarios
//por ultimo vamos a la ultima linea de saludo

/*
Primer codigo
de javascript
Esto esta comentado

*/


//Este es el mensaje de despedida
console.log("esta es la puerta de salida del proyecto")