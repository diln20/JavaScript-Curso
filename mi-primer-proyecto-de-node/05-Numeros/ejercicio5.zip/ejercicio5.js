let altura = 170;
let altura_metro = 1.70;
let peso = 58.9;

//hacia arriba redondeo 
let altura_red = Math.ceil(altura_metro)

//hacia abajo redondeo 
let peso_red = Math.floor(peso)

let sonIguales = Number.MAX_VALUE + 1 === Number.MAX_VALUE