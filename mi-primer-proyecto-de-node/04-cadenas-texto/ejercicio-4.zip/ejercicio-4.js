let nombre = "Dilan";

let apellido = "Torres";

let estudiante = nombre.concat(" ").concat(apellido)

let estudianteMayus = estudiante.toUpperCase()
let estudianteMinus = estudiante.toLowerCase()

let estudianteLength = estudiante.length


let inicialNombre = nombre[0]

let finalApellido = apellido[apellido.length - 1]

let estudianteSinEspacios = estudiante.replace(" ", "")


let nombreEnEstudiante = estudiante.includes(nombre)