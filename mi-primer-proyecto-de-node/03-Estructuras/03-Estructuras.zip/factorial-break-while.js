// ejercicio factorial while if break




let factorial = 1
let num = 1
while (true) {
    if (num === 1) {
        break
    }
    factorial = factorial * num
    num--
}
console.log(factorial) 