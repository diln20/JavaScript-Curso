
//ejercicio 2


//factorial-for

num = 10
let factorial = 1
for (let i = 0; i < num; i++) {
    factorial = factorial * (i + 1)
}
console.log(factorial)

