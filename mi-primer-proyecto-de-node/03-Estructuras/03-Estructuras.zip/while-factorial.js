

//Ejercio while factorial

let num = 10
let i = 0
while (i < 10) {
    num = num * (i + 1)
    console.log(num)
    i++;
}