

const lista = [
    "Dilan",
    23,
    true,
    new Date(1999, 01, 05),
    libro = {
        titulo: "El principito",
        autor: "Antoine de Saint-Exupéry",
        editorial: "Salamandra",
        fecha_publicacion: new Date(1943, 04, 06),
        genero: "Novela",
        idioma: "Frances",
    }
]
